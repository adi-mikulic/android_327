package com.example.joshrubin.testgame;

/**
 * Created by joshrubin on 12/7/17.
 */

public class Collide {

    private boolean collide = false;
    private ChangeListener listener;

    public boolean isCollide() {
        return collide;
    }

    public void setCollide(boolean collide) {
        this.collide = collide;
        if (listener != null) {
            listener.onChange();
        }
    }

    public ChangeListener getListener() {
        return listener;
    }

    public void setListener(ChangeListener listener) {
        this.listener = listener;
    }

    public interface ChangeListener {
        void onChange();
    }

}
