package com.example.joshrubin.testgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

/**
 * Created by joshrubin on 12/5/17.
 */

public class Background {

    private Bitmap background;
    private int x;
    private int y;
    private float speed;
    private static final double B_HEIGHT = 600;
    private static final double B_WIDTH = 1600;
    private static double scale = GameView.S_HEIGHT/B_HEIGHT;
    private static int width = (int) (scale*B_WIDTH);

    public Background(Bitmap background) {
        double scale = GameView.S_HEIGHT/B_HEIGHT;
        int width = (int) (scale*B_WIDTH);
        this.background= Bitmap.createScaledBitmap(background,width,GameView.S_HEIGHT, true);

    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(background,x,y,null);

        if (x<0) {
            canvas.drawBitmap(background,(int)(x+width),y,null);
        }
    }

    public void update() {
        if (MainActivity.start) {
            speed+=.01;
            x-=speed;
        } else {
            speed = 5;
            x-=speed;
        }
        if (x<-width) {
            x=0;
        }
    }
}
