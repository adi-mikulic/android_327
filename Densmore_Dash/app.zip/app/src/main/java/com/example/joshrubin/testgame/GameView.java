package com.example.joshrubin.testgame;


import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static android.content.ContentValues.TAG;

/**
 * Created by joshrubin on 12/4/17.
 */

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    public static MainThread thread;
    public static DoodleGuy doodle;
    private Background background;
    public static Obstacle obstacle1;
    public static Obstacle obstacle2;
    public static Obstacle obstacle3;
    public static Obstacle obstacle4;
    public static boolean hit;
    public static boolean gameUpdate = false;
    public final static int S_HEIGHT = Resources.getSystem().getDisplayMetrics().heightPixels;
    public final static int S_WIDTH = Resources.getSystem().getDisplayMetrics().widthPixels;
    public static int[] place = new int[100];
    public static Obstacle[] obstacleArray;
    private static float points = 0;
    public int count;


    public GameView(Context context) {
        super(context);

        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);
        setFocusable(true);
    }

    public void setArray() {
        for (int i = -50, j = 0; j < 50; i -= 10, j++) {
            place[j] = i;
        }
        for (int i = (int) (GameView.S_HEIGHT - 1758 * Obstacle.scale), j = 50; j < 100; i += 10, j++) {
            place[j] = i;
        }
    }

    public int getRand() {
        int rand = new Random().nextInt(100);
        return place[rand];
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {

        setArray();

        background = new Background(BitmapFactory.decodeResource(getResources(), R.drawable.scrolling_background));

        thread.setRunning(true);
        thread.start();

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
                ;
            } catch (InterruptedException exception) {
                exception.printStackTrace();
            }
            retry = false;
        }
    }

    public void update() {
        if (!hit) {
            background.update();
        }

        if (gameUpdate && !hit) {
            if (checkCollision(obstacleArray, doodle)) {
                hit = true;
            }

            doodle.update();
            obstacle1.update();
            obstacle2.update();
            obstacle3.update();
            obstacle4.update();
            count++;

            for (int i = 0; i < obstacleArray.length; i++) {
                if (obstacleArray[i].pointcheck && obstacleArray[i].x<doodle.x && obstacleArray[i].x>0) {
                    points++;
                    obstacleArray[i].pointcheck=false;
                }
            }

            if (count==1) {
                Log.d("STATE", "update: "+points);
                count=0;
            }
        }
        if (MainActivity.start || MainActivity.restart) {
            doodle = new DoodleGuy(BitmapFactory.decodeResource(getResources(), R.drawable.doodle));
            doodle.setStart(200, 200);
            doodle.setForce(2.5);

            obstacle1 = new Obstacle(BitmapFactory.decodeResource(getResources(), R.drawable.brick_pattern), 2000, getRand());
            obstacle2 = new Obstacle(BitmapFactory.decodeResource(getResources(), R.drawable.brick_pattern), 2000 + (S_WIDTH / 2), getRand());
            obstacle3 = new Obstacle(BitmapFactory.decodeResource(getResources(), R.drawable.brick_pattern), 2000 + (S_WIDTH), getRand());
            obstacle4 = new Obstacle(BitmapFactory.decodeResource(getResources(), R.drawable.brick_pattern), 2000 + (S_WIDTH / 2 * 3), getRand());

            obstacleArray = new Obstacle[4];

            obstacleArray[0] = obstacle1;
            obstacleArray[1] = obstacle2;
            obstacleArray[2] = obstacle3;
            obstacleArray[3] = obstacle4;

            if (MainActivity.start) {
                MainActivity.start = false;
            } else if (MainActivity.restart) {
                MainActivity.restart = false;
            }
            points = 0;
            hit = false;
            gameUpdate = true;

        }
    }

    @Override
    public void draw(Canvas canvas) {

        super.draw(canvas);
        if (canvas != null) {
            background.draw(canvas);
            if (gameUpdate) {
                doodle.draw(canvas);
                obstacle1.draw(canvas);
                obstacle2.draw(canvas);
                obstacle3.draw(canvas);
                obstacle4.draw(canvas);
                Paint paint = new Paint();
                paint.setTextSize(100);
                paint.setColor(Color.BLACK);
                canvas.drawText(""+(int)points,20,100,paint);

            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            doodle.goUp(true);
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            doodle.goUp(false);
        }
        return super.onTouchEvent(event);
    }

    public boolean checkIndividualCollision(Obstacle obstacle, DoodleGuy doodle) {
        int dx = doodle.image.getWidth();
        int dy = doodle.image.getHeight();
        int ox = obstacle.image.getWidth();
        int oy = obstacle.image.getHeight();
        Rect recd = new Rect((int) doodle.x, (int) doodle.y, (int) doodle.x + dx, (int) doodle.y + dy);
        Rect reco = new Rect(obstacle.x, obstacle.y, obstacle.x + ox, obstacle.y + oy);
        return Rect.intersects(recd, reco);
    }

    public boolean checkCollision(Obstacle[] array, DoodleGuy doodle) {
        for (int i = 0; i < array.length; i++) {
            if (checkIndividualCollision(array[i], doodle)) {
                return true;
            }
        }
        return false;
    }





}
