package com.example.joshrubin.testgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import java.util.Random;

/**
 * Created by joshrubin on 12/5/17.
 */

public class Obstacle {

    public Bitmap image;
    public static double scale = .5;
    public int x;
    public int y;
    public int sizeX,sizeY;
    private double speed =7;
    public boolean pointcheck;
    public static int tick;

    public int getRand() {
        int rand = new Random().nextInt(100);
        return GameView.place[rand];
    }

    public Obstacle(Bitmap image, int x, int y) {
        sizeX=(int)(287*scale);
        sizeY=(int)(1758*scale);
        Bitmap nImage = Bitmap.createScaledBitmap(image, sizeX, sizeY, true);
        this.image = nImage;
        this.x=x;
        this.y=y;
        pointcheck=true;
    }

    public void draw(Canvas canvas) {

        canvas.drawBitmap(image, x, y, null);
    }

    public void update() {

        speed+=.01;
        x-=(speed);
        if (x<-GameView.S_WIDTH) {
            x=GameView.S_WIDTH;
            y=getRand();
        }
        tick++;
        if (x==GameView.S_WIDTH) {
            pointcheck=true;
        }


    }

}
